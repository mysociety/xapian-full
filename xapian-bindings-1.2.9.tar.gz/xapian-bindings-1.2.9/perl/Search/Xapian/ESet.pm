package Search::Xapian::ESet;

1;
