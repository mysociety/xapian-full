package Search::Xapian::RSet;

1;
1;
