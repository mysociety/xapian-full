package Search::Xapian::ESetIterator;

1;
