package Search::Xapian::NetworkError;

=head1 NAME

Search::Xapian::NetworkError -  Indicates a problem communicating with a remote database. 


=head1 DESCRIPTION


=cut
1;
