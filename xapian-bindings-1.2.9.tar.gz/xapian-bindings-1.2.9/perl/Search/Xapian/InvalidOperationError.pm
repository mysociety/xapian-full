package Search::Xapian::InvalidOperationError;

=head1 NAME

Search::Xapian::InvalidOperationError -  InvalidOperationError indicates the API was used in an invalid way.

=head1 DESCRIPTION


=cut
1;
